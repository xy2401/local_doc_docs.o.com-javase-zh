This project contains several UI control samples. Perform the following steps to  run a particular sample:

1. Right-click the UIControlSamples project and choose Properties
2. Choose the Run category
3. Click Browse next to the Application Class field
4. Choose the required sample and click Select Class
5. Click Ok
6. Right-click the UIControlSamples project and choose Run
